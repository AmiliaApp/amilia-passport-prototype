(function() {

  window._membershipCards = [{
    Id: 17632745,
    FirstName: 'Martin',
    LastName: 'Drapeau',
    ProfilePictureUrl: 'img/martin.jpg',
    OrganizationLogoUrl: 'img/sports-montreal.jpg',
    OrganizationName: "Sports Montréal",
    OrganizationAddress: "1000 Ave Émile-Journault, Montréal, QC, H2M 2E7, CA",
    OrganizationPhone: "(514) 872-7177",
    OrganizationEmail: "info@sportsmontreal.com",
    OrganizationWebsite: "www.sportsmontreal.com"
  }, {
    Id: 10192837,
    FirstName: 'Emilia',
    LastName: 'Drapeau',
    ProfilePictureUrl: 'img/emilia.jpg',
    OrganizationLogoUrl: 'img/sports-montreal.jpg',
    OrganizationName: "Sports Montréal",
    OrganizationAddress: "1000 Ave Émile-Journault, Montréal, QC, H2M 2E7, CA",
    OrganizationPhone: "(514) 872-7177",
    OrganizationEmail: "info@sportsmontreal.com",
    OrganizationWebsite: "www.sportsmontreal.com"
  }, {
    Id: 20938472,
    FirstName: 'Ludovic',
    LastName: 'Bazinet',
    ProfilePictureUrl: 'img/ludovic.jpg',
    OrganizationLogoUrl: 'img/sports-montreal.jpg',
    OrganizationName: "Sports Montréal",
    OrganizationAddress: "1000 Ave Émile-Journault, Montréal, QC, H2M 2E7, CA",
    OrganizationPhone: "(514) 872-7177",
    OrganizationEmail: "info@sportsmontreal.com",
    OrganizationWebsite: "www.sportsmontreal.com"
  }, {
    Id: 30293847,
    FirstName: 'Eloi',
    LastName: 'Drapeau',
    ProfilePictureUrl: 'img/eloi.jpg',
    OrganizationLogoUrl: 'img/sports-montreal.jpg',
    OrganizationName: "Sports Montréal",
    OrganizationAddress: "1000 Ave Émile-Journault, Montréal, QC, H2M 2E7, CA",
    OrganizationPhone: "(514) 872-7177",
    OrganizationEmail: "info@sportsmontreal.com",
    OrganizationWebsite: "www.sportsmontreal.com"
  }];

}.call(this));